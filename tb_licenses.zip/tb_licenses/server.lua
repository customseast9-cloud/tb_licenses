print("^2[tb_licenses]^0 Purchased from: ^5https://tbscripts.tebex.io^0")
print("^2[tb_licenses]^0 Discord: ^5https://discord.gg/TEAFt8WwhD^0")
-- tb_licenses/server.lua

-- Config is global
local QBCore = exports['qb-core']:GetCoreObject()


-- Make all license items usable: show to self or nearest player
local function getAllLicenseItems()
    local items = {}
    for _, lic in ipairs(Config.Licenses) do
        if lic.item then table.insert(items, lic.item) end
    end
    return items
end

for _, itemName in ipairs(getAllLicenseItems()) do
    QBCore.Functions.CreateUseableItem(itemName, function(source, item)
        TriggerClientEvent('tb_licenses:showLicense', source, item.name)
    end)
end




RegisterNetEvent('tb_licenses:buyLicense', function(licenseType, price, isRenewal)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local licenses = Player.PlayerData.licenses
    if type(licenses) ~= 'table' then
        licenses = {}
        Player.Functions.SetMetaData('licenses', licenses)
    end
    local licenseExpiries = Player.PlayerData.licenseExpiries or {}

    -- Require driver's license ITEM for all licenses except driver's license itself
    if licenseType ~= 'driver' then
        local hasDriverItem = Player.Functions.GetItemByName('driver_license') ~= nil
        if not hasDriverItem then
            TriggerClientEvent('tb_licenses:notify', src, L('notify_need_driver'))
            return
        end
    end

    -- Get license config
    local licConfig = nil
    for _, lic in ipairs(Config.Licenses) do
        if lic.type == licenseType then licConfig = lic break end
    end
    if not licConfig then
        TriggerClientEvent('tb_licenses:notify', src, L('notify_license_not_configured'))
        return
    end
    local itemName = licConfig.item

    -- Check for existing license (unless renewal)
    if not isRenewal and (licenses[licenseType] or Player.Functions.GetItemByName(itemName)) then
        TriggerClientEvent('tb_licenses:notify', src, L('notify_already_owned'))
        return
    end

    if Player.PlayerData.money.cash >= price then
        Player.Functions.RemoveMoney('cash', price)
        licenses[licenseType] = true
        -- Set expiry date (current time + expiryDays)
        if licConfig.expiryDays and licConfig.renewable then
            local expiry = os.time() + (licConfig.expiryDays * 24 * 60 * 60)
            licenseExpiries[licenseType] = expiry
            Player.Functions.SetMetaData('licenseExpiries', licenseExpiries)
        end
        Player.Functions.SetMetaData('licenses', licenses)
        Player.PlayerData.licenses = licenses -- ensure in-memory sync
        if not isRenewal and QBCore.Shared.Items[itemName] then
            local info = {}
            if Player.PlayerData.charinfo then
                info.firstname = Player.PlayerData.charinfo.firstname or ''
                info.lastname = Player.PlayerData.charinfo.lastname or ''
                info.birthdate = Player.PlayerData.charinfo.birthdate or ''
            end
            Player.Functions.AddItem(itemName, 1, false, info)
            TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[itemName], 'add')
        end
        local msg
        if isRenewal then
            msg = L('notify_renewed', Config.LicenseLabel[licenseType] or licenseType)
        else
            msg = L('notify_bought', Config.LicenseLabel[licenseType] or licenseType)
        end
        TriggerClientEvent('tb_licenses:notify', src, msg)
    else
        TriggerClientEvent('tb_licenses:notify', src, L('notify_no_cash'))
    end
end)

    -- License renewal event
    RegisterNetEvent('tb_licenses:renewLicense', function(type)
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        local licenses = Player.PlayerData.licenses or {}
        local licenseExpiries = Player.PlayerData.licenseExpiries or {}
        local licConfig = nil
        for _, lic in ipairs(Config.Licenses) do
            if lic.type == type then licConfig = lic break end
        end
        if not licConfig or not licConfig.renewable then
            -- Removed F8 notification
            return
        end
        if not licenses[type] then
            -- Removed F8 notification
            return
        end
        -- Check if expired
        local now = os.time()
        local expiry = licenseExpiries[type] or 0
        if expiry > now then
            -- Removed F8 notification
            return
        end
        -- Use buyLicense logic with isRenewal flag
        TriggerEvent('tb_licenses:buyLicense', type, licConfig.price, true)
    end)

    -- Check license expiry for client display
    RegisterNetEvent('tb_licenses:checkLicenseExpiry', function(type)
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        local licenses = Player.PlayerData.licenses or {}
        local licenseExpiries = Player.PlayerData.licenseExpiries or {}
        local licConfig = nil
        for _, lic in ipairs(Config.Licenses) do
            if lic.type == type then licConfig = lic break end
        end
        local expired = false
        local expiryDate = nil
        if licConfig and licConfig.expiryDays and licConfig.renewable then
            expiryDate = licenseExpiries[type] or 0
            expired = expiryDate < os.time()
        end
        TriggerClientEvent('tb_licenses:licenseExpiryResult', src, type, expired, expiryDate, licConfig and licConfig.label or type, licConfig and licConfig.description or '')
    end)

QBCore.Functions.CreateCallback('tb_licenses:getPlayerLicenses', function(src, cb, target)
    local Player = QBCore.Functions.GetPlayer(tonumber(target))
    if not Player then cb({}) return end
    local licenses = Player.PlayerData.licenses or {}
    local result = {}
    for type, has in pairs(licenses) do
        if has then
            table.insert(result, {type = type})
        end
    end
    cb(result)
end)
