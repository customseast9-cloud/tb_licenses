    // Always hide menu on load
    document.getElementById('license-menu').style.display = 'none';

    window.addEventListener('message', function(event) {
        if (event.data.action === 'showMenu') {
            document.getElementById('license-menu').style.display = 'block';
            document.getElementById('menu-title').textContent = event.data.title || 'License Center';
            renderLicenses(event.data.licenses || []);
        } else if (event.data.action === 'hideMenu') {
            document.getElementById('license-menu').style.display = 'none';
        }
    });

    // ESC key closes menu
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && document.getElementById('license-menu').style.display === 'block') {
            document.getElementById('license-menu').style.display = 'none';
            fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
        }
    });

    document.getElementById('close-btn').onclick = function() {
        document.getElementById('license-menu').style.display = 'none';
        fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
    };


    const buyBtn = document.getElementById('buyBtn');
    if (buyBtn) {
        buyBtn.addEventListener('click', function() {
            const selected = document.querySelector('input[name="licenseOption"]:checked');
            buyBtn.disabled = true;
            if (selected) {
                document.getElementById('license-menu').style.display = 'none';
                fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
                // Actually trigger the NUI buyLicense callback
                fetch(`https://${GetParentResourceName()}/buyLicense`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: selected.value })
                }).finally(() => {
                    buyBtn.disabled = false;
                });
            } else {
                fetch(`https://${GetParentResourceName()}/notify`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ msg: 'Please select a license to buy.' })
                }).finally(() => {
                    buyBtn.disabled = false;
                });
            }
        });
    }

document.getElementById('close-btn').onclick = function() {
    document.getElementById('license-menu').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
};

function renderLicenses(licenses) {
    const list = document.getElementById('licenses-list');
    list.innerHTML = '';
    licenses.forEach(lic => {
        const container = document.createElement('div');
        container.style.marginBottom = '16px';
        const btn = document.createElement('button');
        btn.className = 'license-btn';
        btn.textContent = `${lic.label} - $${lic.price}`;
        btn.onclick = function() {
            if (btn.disabled) return;
            btn.disabled = true;
            document.getElementById('license-menu').style.display = 'none';
            fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
            // Trigger buyLicense NUI callback directly, only once
            fetch(`https://${GetParentResourceName()}/buyLicense`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: lic.type })
            }).finally(() => {
                setTimeout(() => { btn.disabled = false; }, 1000);
            });
        };
        container.appendChild(btn);

        // Add Renew button for expired licenses (client-side check, can be improved with server data)
        if (lic.expired) {
            const renewBtn = document.createElement('button');
            renewBtn.className = 'license-btn';
            renewBtn.style.background = '#2e8b57';
            renewBtn.style.marginLeft = '8px';
            renewBtn.textContent = `Renew ${lic.label} - $${lic.price}`;
            renewBtn.onclick = function() {
                document.getElementById('license-menu').style.display = 'none';
                fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
                fetch(`https://${GetParentResourceName()}/renewLicense`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ type: lic.type })
                });
            };
            container.appendChild(renewBtn);
        }

        if (lic.description) {
            const desc = document.createElement('div');
            desc.style.fontSize = '0.95em';
            desc.style.color = '#b0c4de';
            desc.style.marginTop = '4px';
            desc.textContent = lic.description;
            container.appendChild(desc);
        }
        list.appendChild(container);
    });
}

// Hide menu on ESC
window.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('license-menu').style.display = 'none';
        fetch(`https://${GetParentResourceName()}/closeMenu`, { method: 'POST' });
    }
});
