
local QBCore = exports['qb-core']:GetCoreObject()

local pedSpawned = false
local pedEntity = nil
local menuOpen = false


RegisterNetEvent('tb_licenses:notify')
AddEventHandler('tb_licenses:notify', function(msg)
    Config.Notify(msg)
end)
-- Show license to self (popup, can be extended to show to nearest player)
RegisterNetEvent('tb_licenses:showLicense')
AddEventHandler('tb_licenses:showLicense', function(itemName)
    local license = nil
    for _, lic in ipairs(Config.Licenses) do
        if lic.item == itemName then license = lic break end
    end
    if not license then
        Config.Notify(L('notify_license_info_not_found'))
        return
    end
    -- Show a simple notification for now; can be replaced with a UI popup
    local msg = ('%s\n%s'):format(license.label, license.description or '')
    Config.Notify(msg)
end)


RegisterNetEvent('tb_licenses:licenseExpiryResult')
AddEventHandler('tb_licenses:licenseExpiryResult', function(type, expired, expiryDate, label, description)
    local msg = ''
    if expired then
        msg = ('%s\n%s\n%s\n%s'):format(label, L('expired'), description or '', L('renew_at_center'))
    else
        local expStr = expiryDate and os.date('%Y-%m-%d', expiryDate) or 'N/A'
        msg = ('%s\n%s %s\n%s'):format(label, L('expires'), expStr, description or '')
    end
    Config.Notify(msg)
end)
-- Police command to check licenses
RegisterCommand('checklicenses', function(source, args)
    local target = tonumber(args[1])
    if not target then
        Config.Notify(L('notify_usage'))
        return
    end
    TriggerServerEvent('qb-core:server:triggerCallback', 'tb_licenses:getPlayerLicenses', target)
end, false)

RegisterNetEvent('qb-core:client:triggerCallback')
AddEventHandler('qb-core:client:triggerCallback', function(name, result)
    if name == 'tb_licenses:getPlayerLicenses' then
        TriggerEvent('tb_licenses:showPlayerLicenses', result)
    end
end)



AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        if pedEntity and DoesEntityExist(pedEntity) then
            DeleteEntity(pedEntity)
        end
        SetNuiFocus(false, false)
    end
end)

function DrawText3D(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

function SpawnLicensePed()
    if pedSpawned then return end
    local model = GetHashKey(Config.Ped.model)
    RequestModel(model)
    local waited = 0
    while not HasModelLoaded(model) do
        Wait(10)
        waited = waited + 10
        if waited > 5000 then
            Config.Notify(L('notify_ped_model_failed', tostring(Config.Ped.model)))
            return
        end
    end
    pedEntity = CreatePed(4, model, Config.Ped.coords.x, Config.Ped.coords.y, Config.Ped.coords.z - 1.0, Config.Ped.heading, false, true)
    if pedEntity and pedEntity > 0 then
        SetEntityInvincible(pedEntity, true)
        SetBlockingOfNonTemporaryEvents(pedEntity, true)
        TaskStartScenarioInPlace(pedEntity, Config.Ped.scenario, 0, true)
        pedSpawned = true
    else
        Config.Notify(L('notify_ped_failed'))
        pedSpawned = false
    end
end

Citizen.CreateThread(function()
    SpawnLicensePed()
    -- Add map blip for license center
    local blip = AddBlipForCoord(Config.Ped.coords.x, Config.Ped.coords.y, Config.Ped.coords.z)
    if blip then
        SetBlipSprite(blip, 498)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.9)
        SetBlipColour(blip, 3)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("License Center")
        EndTextCommandSetBlipName(blip)
    else
        Config.Notify("Blip failed to add.")
    end

    while true do
        Wait(0)
        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local dist = #(coords - Config.Ped.coords)
        if not pedSpawned then
            DrawMarker(1, Config.Ped.coords.x, Config.Ped.coords.y, Config.Ped.coords.z - 1.0, 0, 0, 0, 0, 0, 0, 1.0, 1.0, 1.0, 0, 255, 0, 150, false, true, 2, false, '', '', false)
        end
        if dist < 2.0 then
            DrawText3D(Config.Ped.coords.x, Config.Ped.coords.y, Config.Ped.coords.z + 1.0, "Press ~g~E~w~ to open License Menu")
            if IsControlJustReleased(0, 38) then
                OpenLicenseMenu()
            end
        end
    end
end)

function OpenLicenseMenu()
    if menuOpen then return end
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'showMenu',
        title = Config.MenuTitle,
        licenses = Config.Licenses
    })
end

RegisterNUICallback('closeMenu', function(_, cb)
    SetNuiFocus(false, false)
    menuOpen = false
    cb('ok')
end)



RegisterNUICallback('buyLicense', function(data, cb)
    SetNuiFocus(false, false)
    menuOpen = false
    if not data.type then
        Config.Notify(L('notify_select_license'))
        cb('ok')
        return
    end
    -- Find the license config to get the price
    local licConfig = nil
    for _, lic in ipairs(Config.Licenses) do
        if lic.type == data.type then licConfig = lic break end
    end
    if not licConfig then
        Config.Notify(L('notify_license_not_found'))
        cb('ok')
        return
    end
    -- Trigger server event to buy license
    TriggerServerEvent('tb_licenses:buyLicense', data.type, licConfig.price)
    cb('ok')
end)

RegisterNUICallback('notify', function(data, cb)
    if data and data.msg then
        Config.Notify(data.msg)
    end
    cb('ok')
end)



RegisterNetEvent('tb_licenses:showPlayerLicenses')
AddEventHandler('tb_licenses:showPlayerLicenses', function(licenses)
    local text = ''
    for _, lic in ipairs(licenses) do
        local label = Config.LicenseLabel and Config.LicenseLabel[lic.type] or lic.type
        text = text .. (label .. '\n')
    end
    Config.Notify(L('notify_licenses', text))
end)
