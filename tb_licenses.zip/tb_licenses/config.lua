-- Main configuration for tb_licenses script

Config = {}

-- PED configuration
Config.Ped = {
    model = "a_m_m_skater_01", -- Change to your desired PED model
    coords = vector3(-266.28, -967.53, 31.22), -- Updated PED coordinates
    heading = 261.15, -- Updated heading
    scenario = "WORLD_HUMAN_CLIPBOARD" -- Change to your desired PED scenarios
}
-- License types and prices---
Config.Licenses= {
    {
        label = "Driver's License",
        type = "driver",
        item = "driver_license",
        image = "images/driver_license.png",
        price = 500,
        renewPrice = 250,
        description = "Required to operate standard motor vehicles such as cars and light trucks on public roads.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "driving"
    },
    {
        label = "Class A CDL",
        type = "cdl_a",
        item = "cdl_a",
        image = "images/cdl_a.png",
        price = 2000,
        renewPrice = 1000,
        description = "Required for any combination of vehicles with a GCWR of 26,001 lbs or more, including a towed vehicle that is heavier than 10,000 lbs. This includes tractor-trailers, truck and trailer combinations, and double or triple trailers.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "commercial"
    },
    {
        label = "Class B CDL",
        type = "cdl_b",
        item = "cdl_b",
        image = "images/cdl_b.png",
        price = 1800,
        renewPrice = 900,
        description = "Required for a single vehicle with a GVWR of 26,001 lbs or heavier, such as straight trucks, city buses, and school buses.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "commercial"
    },
    {
        label = "Class C CDL",
        type = "cdl_c",
        item = "cdl_c",
        image = "images/cdl_c.png",
        price = 1600,
        renewPrice = 800,
        description = "Required for vehicles designed to transport 16 or more passengers or carry placarded hazardous materials.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "commercial"
    },
    {
        label = "Double/Triple Trailer Endorsement",
        type = "cdl_double_triple",
        item = "cdl_double_triple",
        image = "images/cdl_double_triple.png",
        price = 600,
        renewPrice = 300,
        description = "Allows drivers to haul two or three trailers simultaneously. Requires a valid Class C license and additional training and tests.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "commercial"
    },
    {
        label = "Hazardous Materials Endorsement",
        type = "cdl_hazmat",
        item = "cdl_hazmat",
        image = "images/cdl_hazmat.png",
        price = 700,
        renewPrice = 350,
        description = "Required for transporting hazardous materials. Requires additional training and tests.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "commercial"
    },
    {
        label = "Passenger Vehicle Endorsement",
        type = "cdl_passenger",
        item = "cdl_passenger",
        image = "images/cdl_passenger.png",
        price = 500,
        renewPrice = 250,
        description = "Allows drivers to operate passenger vehicles like buses. Requires additional training and tests.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "commercial"
    },
    {
        label = "Hunting License",
        type = "hunting",
        item = "hunting_license",
        image = "images/hunting_license.png",
        price = 800,
        renewPrice = 400,
        description = "Required to legally hunt wildlife. Check local regulations for allowed species and seasons.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "recreational"
    },

   {
        label = "Fishing License",
        type = "fishing",
        item = "fishing_license",
        image = "images/fishing_license.png",
        price = 400,
        renewPrice = 200,
        description = "Required to fish in public waters. Ensure compliance with catch limits and local rules.",
        expiryDays = 30,
        renewable = true,  ----- true means the license can be renewed after expiry, false means it cannot be renewed and must be repurchased
        canBeRevoked = true,
        category = "recreational"
    },
    {
        label = "Marijuana Card",
        type = "marijuana_card",
        item = "marijuana_card",
        image = "images/marijuana_card.png",
        price = 400,
        renewPrice = 200,
        description = "Required to legally possess and use marijuana. Ensure compliance with local regulations and licensing requirements.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "recreational"
    },
    {
        label = "Pilot License",
        type = "pilot",
        item = "pilot_license",
        image = "images/pilot_license.png",
        price = 400,
        description = "Required to operate aircraft. Ensure compliance with local regulations and licensing requirements.",
        expiryDays = 30,
        renewable = true,
        canBeRevoked = true,
        category = "recreational"
    }


}



-- Embedded English locale for client/server
Config.Lang = {
    notify_bought = "You bought a %s license!",
    notify_already_owned = "You already own this license!",
    notify_no_cash = "You do not have enough cash to buy this license!",
    notify_need_driver = "You must have a Driver's License before buying this license!",
    notify_license_not_configured = "License item not configured!",
    notify_license_info_not_found = "License info not found!",
    notify_renewed = "You renewed your %s!",
    notify_select_license = "Please select a license to buy.",
    notify_license_not_found = "License not found!",
    notify_usage = "Usage: /checklicenses [player id]",
    notify_ped_model_failed = "PED model failed to load: %s",
    notify_ped_failed = "PED failed to spawn. Showing marker instead.",
    notify_blip_failed = "Blip failed to add.",
    notify_licenses = "Licenses:\n%s",
    expired = "[EXPIRED]",
    renew_at_center = "Renew at the License Center.",
    expires = "Expires: %s",
}

-- Helper: Get localized string
function L(key, ...)
    local str = Config.Lang[key] or key
    if select('#', ...) > 0 then
        return string.format(str, ...)
    end
    return str
end

Config.MenuTitle = "License Center"

if not QBCore then
    QBCore = exports['qb-core']:GetCoreObject()
end
Config.Notify = function(msg)
    if QBCore and QBCore.Functions and QBCore.Functions.Notify then
        QBCore.Functions.Notify(msg)
    else
        TriggerEvent('QBCore:Notify', msg)
    end
end

-- Helper: Map license type to label
Config.LicenseLabel = {}
for _, lic in ipairs(Config.Licenses) do
    Config.LicenseLabel[lic.type] = lic.label
end

-- No return, Config is global

