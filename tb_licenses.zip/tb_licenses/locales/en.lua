-- tb_licenses/locales/en.lua

Locales = {}

Locales['en'] = {
    notify_bought = "You bought a %s license!",
    notify_already_owned = "You already own this license!",
    notify_no_cash = "You do not have enough cash to buy this license!",
    notify_need_driver = "You must have a Driver's License before buying this license!",
    notify_license_not_configured = "License item not configured!",
    notify_license_info_not_found = "License info not found!",
    notify_renewed = "You renewed your %s!",
    notify_select_license = "Please select a license to buy.",
    notify_license_not_found = "License not found!",
    notify_usage = "Usage: /checklicenses [player id]",
    notify_ped_model_failed = "PED model failed to load: %s",
    notify_ped_failed = "PED failed to spawn. Showing marker instead.",
    notify_blip_failed = "Blip failed to add.",
    notify_licenses = "Licenses:\n%s",
    expired = "[EXPIRED]",
    renew_at_center = "Renew at the License Center.",
    expires = "Expires: %s",
}

return Locales['en']
