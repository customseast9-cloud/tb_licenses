-- Command for police to check a player's licenses
-- Usage: /checklicenses [id]

RegisterCommand('checklicenses', function(source, args)
    local target = tonumber(args[1])
    if not target then
        Config.Notify('Usage: /checklicenses [player id]')
        return
    end
    TriggerServerEvent('qb-core:server:triggerCallback', 'tb_licenses:getPlayerLicenses', target)
end, false)

RegisterNetEvent('qb-core:client:triggerCallback')
AddEventHandler('qb-core:client:triggerCallback', function(name, result)
    if name == 'tb_licenses:getPlayerLicenses' then
        TriggerEvent('tb_licenses:showPlayerLicenses', result)
    end
end)
