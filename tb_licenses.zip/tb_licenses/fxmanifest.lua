fx_version 'cerulean'
game 'gta5'

author 'TB SCRIPTS'
description 'tb_licenses: Buy licenses at a PED with a menu.'
version '1.0.0'

shared_script 'config.lua'
client_scripts {
    'client.lua',
    'police.lua'
}
server_script 'server.lua'

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'locales/en.lua'
}

 escrow_ignore {
 'config.lua'
}
dependency 'qb-core'

